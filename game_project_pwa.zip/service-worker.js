// Nama cache
const CACHE_NAME = "kubus3d-cache-v1";

// File yang dicache
const ASSETS = [
  "/",
  "/index.html",
  "/manifest.json",
  "/js/gameCore.js",
  "/js/gameObjects.js",
  "/js/gameLogic.js",
  "/js/controls.js",
  "/js/audio.js",
  "/assets/icon-192.png",
  "/assets/icon-512.png"
];

// Install Service Worker
self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      console.log("Service Worker: Caching files");
      return cache.addAll(ASSETS);
    })
  );
});

// Aktivasi Service Worker
self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))
      )
    )
  );
  console.log("Service Worker: Activated");
});

// Fetch request
self.addEventListener("fetch", event => {
  event.respondWith(
    caches.match(event.request).then(res => {
      return res || fetch(event.request);
    })
  );
});
